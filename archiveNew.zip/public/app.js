'use strict';

const $  = id  => document.getElementById(id);
const $$ = sel => document.querySelector(sel);

let sse            = null;
let logCount       = 0;
let rpsCount       = 0;
let rpsTimer       = null;
let stats          = { total: 0, valid: 0, invalid: 0, errors: 0 };
let generatedCodes = [];

setInterval(() => {
  $('clock').textContent = new Date().toLocaleTimeString('en-US', { hour12: false });
}, 1000);

document.querySelectorAll('.nav-item').forEach(btn => {
  btn.addEventListener('click', () => {
    const tab = btn.dataset.tab;
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    $(`panel-${tab}`).classList.add('active');
  });
});

function ts() {
  return new Date().toLocaleTimeString('en-US', { hour12: false });
}

function log(icon, msg, cls = 'muted') {
  const el = $('log');
  const empty = el.querySelector('.empty-msg');
  if (empty) empty.remove();

  const line = document.createElement('div');
  line.className = 'log-line';
  line.innerHTML =
    `<span class="log-ts">${ts()}</span>` +
    `<span class="log-icon">${icon}</span>` +
    `<span class="log-msg ${cls}">${esc(msg)}</span>`;
  el.appendChild(line);
  el.scrollTop = el.scrollHeight;

  logCount++;
  $('log-count').textContent = `${logCount} entries`;
}

function esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function status(msg) { $('sb-status').textContent = msg; }

function setOnline(on) {
  const dot  = $('live-dot');
  const lbl  = $('conn-label');
  dot.classList.toggle('on', on);
  lbl.textContent = on ? 'Live' : 'Offline';
}

function updateStats(s) {
  stats = { ...stats, ...s };
  $('stat-total').textContent   = stats.total;
  $('stat-valid').textContent   = stats.valid;
  $('stat-invalid').textContent = stats.invalid;
  $('stat-errors').textContent  = stats.errors;
  $('badge-valid').textContent   = `${stats.valid} valid`;
  $('badge-invalid').textContent = `${stats.invalid} invalid`;
  const pct = stats.total > 0 ? ((stats.valid / stats.total) * 100) : 0;
  $('hit-rate').textContent = stats.total > 0 ? pct.toFixed(3) + '%' : '—';
}

function setProgress(done, total) {
  const wrap = $('progress-wrap');
  wrap.style.display = 'block';
  const pct = total > 0 ? Math.round((done / total) * 100) : 0;
  $('prog-label').textContent = `Scanning ${done} / ${total}`;
  $('prog-pct').textContent   = pct + '%';
  $('prog-bar').style.width   = pct + '%';
}

function hideProgress() {
  $('progress-wrap').style.display = 'none';
  $('prog-bar').style.width = '0%';
}

function lockScan(locked) {
  $('btn-check').disabled = locked;
  $('btn-stop').disabled  = !locked;
  $('btn-generate').disabled = locked;
  $('btn-single').disabled   = locked;
}

function startRps() {
  rpsCount = 0;
  rpsTimer = setInterval(() => {
    $('sb-rps').textContent = rpsCount + ' req/s';
    rpsCount = 0;
  }, 1000);
}

function stopRps() {
  clearInterval(rpsTimer);
  $('sb-rps').textContent = '0 req/s';
}

function stopScan() {
  if (sse) { sse.close(); sse = null; }
  stopRps(); lockScan(false); setOnline(false); hideProgress();
  status('Stopped.');
}

function clearCodeList() {
  $('code-list').innerHTML = '';
}

function addCodeItem(code, idx, badge = 'pending') {
  const el = $('code-list');
  const empty = el.querySelector('.empty-msg');
  if (empty) empty.remove();

  const item = document.createElement('div');
  item.className = 'code-item';
  item.id = `ci-${code}`;
  item.innerHTML =
    `<span class="code-num">${idx}</span>` +
    `<span class="code-val" title="${esc(code)}">${esc(code)}</span>` +
    `<span class="code-badge ${badge}" id="cb-${esc(code)}">${badge.toUpperCase()}</span>` +
    `<button class="copy-btn" data-code="${esc(code)}">Copy</button>`;
  el.appendChild(item);
}

function setCodeBadge(code, status_) {
  const badge = $(`cb-${code}`);
  if (!badge) return;
  badge.className = `code-badge ${status_}`;
  badge.textContent = status_.toUpperCase();
  if (status_ === 'valid') badge.closest('.code-item')?.classList.add('flash-valid');
}

$('code-list').addEventListener('click', e => {
  if (!e.target.classList.contains('copy-btn')) return;
  const code = e.target.dataset.code;
  navigator.clipboard.writeText(`https://discord.gift/${code}`).then(() => {
    const btn = e.target;
    btn.textContent = '✓';
    setTimeout(() => { btn.textContent = 'Copy'; }, 1200);
  });
});

$('btn-generate').addEventListener('click', async () => {
  const count  = parseInt($('inp-gen-count').value)  || 20;
  const length = parseInt($('inp-gen-length').value) || 16;

  log('⚡', `Generating ${count} codes (length ${length})…`, 'blue');
  status('Generating…');

  try {
    const res  = await fetch('/api/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ count, length }),
    });
    const data = await res.json();
    if (!data.ok) throw new Error(data.error);

    generatedCodes = data.codes.map(c => c.code);
    clearCodeList();
    generatedCodes.forEach((code, i) => addCodeItem(code, i + 1));
    log('✓', `Generated ${data.count} codes.`, 'green');
    status(`${data.count} codes generated.`);
  } catch (e) {
    log('✗', `Error: ${e.message}`, 'red');
    status('Generate failed.');
  }
});

$('btn-check').addEventListener('click', () => {
  const count   = parseInt($('inp-check-count').value)  || 10;
  const conc    = parseInt($('inp-check-conc').value)   || 2;
  const delay   = parseInt($('inp-check-delay').value)  || 500;
  const token   = $('inp-token').value.trim();
  const webhook = $('inp-webhook').value.trim();

  stats = { total: 0, valid: 0, invalid: 0, errors: 0 };
  updateStats(stats);
  lockScan(true);
  setOnline(true);
  startRps();

  const params = new URLSearchParams({ count, conc, delay });
  if (token)   params.set('token',   token);
  if (webhook) params.set('webhook', webhook);

  log('🔍', `Starting scan — ${count} codes · ${conc} workers · ${delay}ms delay`, 'blue');
  status('Connecting…');

  const es = new EventSource(`/api/scan?${params}`);
  sse = es;

  es.addEventListener('start', e => {
    const d = JSON.parse(e.data);
    clearCodeList();
    generatedCodes = d.codes.map(url => url.replace('https://discord.gift/', ''));
    generatedCodes.forEach((code, i) => addCodeItem(code, i + 1, 'pending'));
    setProgress(0, d.total);
    status(`Scanning ${d.total} codes…`);
    log('📡', `Stream started — ${d.total} codes queued`, 'blue');
  });

  es.addEventListener('result', e => {
    const d = JSON.parse(e.data);
    rpsCount++;
    setCodeBadge(d.code, d.status === 'ratelimit' ? 'pending' : d.status);
    updateStats({ total: d.checked, valid: d.valid, invalid: d.invalid });
    setProgress(d.checked, d.total);

    if (d.status === 'valid')      log('🎉', d.message, 'green');
    else if (d.status === 'ratelimit') log('⏳', d.message, 'yellow');
    else if (d.status === 'error') log('⚠', d.message, 'yellow');
    else                           log('·', d.message, 'muted');
  });

  es.addEventListener('done', e => {
    const d = JSON.parse(e.data);
    log('✓', `Done — ${d.valid} valid / ${d.invalid} invalid / ${d.errors} errors`, 'green');
    status(d.valid > 0 ? `🎉 ${d.valid} valid code(s) found!` : 'Scan complete. No valid codes.');
    stopScan();
  });

  es.addEventListener('webhook', e => {
    const d = JSON.parse(e.data);
    if (d.ok) {
      log('📨', `Webhook sent for ${d.code} — delivered (HTTP ${d.httpStatus})`, 'green');
    } else {
      log('📨', `Webhook for ${d.code} — failed (HTTP ${d.httpStatus ?? 'error'})`, 'yellow');
    }
  });

  es.onerror = () => {
    if (es.readyState === EventSource.CLOSED) return;
    log('✗', 'Stream error.', 'red');
    status('Stream error.');
  };
});

$('btn-stop').addEventListener('click', () => {
  log('⛔', 'Scan stopped by user.', 'yellow');
  stopScan();
});

$('btn-single').addEventListener('click', async () => {
  const code  = $('inp-single').value.trim();
  const token = $('inp-token-single').value.trim();
  const res_el = $('single-result');

  if (!code) return;

  $('btn-single').disabled = true;
  res_el.style.display = 'none';
  res_el.className = 'single-result';

  log('🎯', `Checking: ${code}`, 'blue');
  status('Checking…');

  try {
    const res  = await fetch('/api/check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code, token: token || null }),
    });
    const data = await res.json();
    if (!data.ok) throw new Error(data.error);

    const r = data.result;
    const cls = r.status === 'valid' ? 'green' : r.status === 'invalid' ? 'invalid' : 'error';
    res_el.className = `single-result ${cls}`;
    res_el.textContent = r.message;
    res_el.style.display = 'block';

    if (r.status === 'valid') {
      log('🎉', r.message, 'green');
      if (r.data?.subscription_plan) {
        const pl = r.data.subscription_plan;
        log('📌', `${pl.name} · $${((pl.price || 0) / 100).toFixed(2)}/mo`, 'purple');
      }
      updateStats({ total: stats.total + 1, valid: stats.valid + 1 });
    } else {
      log(r.status === 'invalid' ? '✗' : '⚠', r.message, r.status === 'invalid' ? 'red' : 'yellow');
      updateStats({ total: stats.total + 1 });
    }
    status(r.status === 'valid' ? '🎉 Valid!' : 'Done.');
  } catch (e) {
    log('✗', `Error: ${e.message}`, 'red');
    res_el.className = 'single-result error';
    res_el.textContent = e.message;
    res_el.style.display = 'block';
    status('Error.');
  } finally {
    $('btn-single').disabled = false;
  }
});

$('btn-clear-log').addEventListener('click', () => {
  $('log').innerHTML = '<div class="empty-msg">Log cleared.</div>';
  logCount = 0;
  $('log-count').textContent = '0 entries';
});

$('btn-export').addEventListener('click', () => {
  const lines = [...document.querySelectorAll('.log-line')].map(l =>
    `[${l.querySelector('.log-ts')?.textContent}] ${l.querySelector('.log-icon')?.textContent} ${l.querySelector('.log-msg')?.textContent}`
  );
  const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `enzotool-log-${Date.now()}.txt`;
  a.click();
  URL.revokeObjectURL(a.href);
  log('💾', 'Log exported.', 'blue');
});

$('btn-copy-all').addEventListener('click', () => {
  if (!generatedCodes.length) return;
  const text = generatedCodes.map(c => `https://discord.gift/${c}`).join('\n');
  navigator.clipboard.writeText(text).then(() => {
    log('📋', `Copied ${generatedCodes.length} URLs to clipboard.`, 'blue');
  });
});

log('🚀', 'EnzoTool ready. Waiting for action.', 'blue');
