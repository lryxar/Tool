'use strict';
'use strict';

const CHARSET     = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
const CODE_LENGTH = 16;

function generateCode(length = CODE_LENGTH) {
  let code = '';
  for (let i = 0; i < length; i++)
    code += CHARSET[Math.floor(Math.random() * CHARSET.length)];
  return code;
}

function generateBatch(count = 10, length = CODE_LENGTH) {
  const set = new Set();
  while (set.size < count) set.add(generateCode(length));
  return [...set];
}

function toGiftURL(code) {
  return `https://discord.gift/${code}`;
}

function isValidFormat(code) {
  return /^[A-Za-z0-9]{16}$/.test(code) || /^[A-Za-z0-9]{24}$/.test(code);
}

module.exports = { generateCode, generateBatch, toGiftURL, isValidFormat, CODE_LENGTH };
