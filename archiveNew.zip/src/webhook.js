'use strict';

const https = require('https');

function sendWebhook(webhookUrl, result) {
  if (!webhookUrl) return Promise.resolve();

  let parsed;
  try { parsed = new URL(webhookUrl); } catch (_) { return Promise.resolve(); }

  const embed = {
    title: '🎉 Valid Nitro Code Found!',
    color: 0x22c55e,
    fields: [
      { name: 'Code', value: `\`${result.code}\``, inline: true },
      { name: 'URL',  value: `https://discord.gift/${result.code}`, inline: true },
    ],
    footer: { text: 'EnzoTool' },
    timestamp: new Date().toISOString(),
  };

  if (result.data?.subscription_plan) {
    const plan = result.data.subscription_plan;
    embed.fields.push({
      name:   'Plan',
      value:  `${plan.name} — $${((plan.price || 0) / 100).toFixed(2)}/mo`,
      inline: false,
    });
  }

  const body = JSON.stringify({
    username: 'EnzoTool',
    avatar_url: 'https://cdn.discordapp.com/embed/avatars/0.png',
    embeds: [embed],
  });

  return new Promise((resolve) => {
    const req = https.request({
      hostname: parsed.hostname,
      path:     parsed.pathname + parsed.search,
      method:   'POST',
      headers:  { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
    }, (res) => { res.resume(); resolve(res.statusCode); });
    req.on('error', () => resolve(null));
    req.setTimeout(8_000, () => { req.destroy(); resolve(null); });
    req.write(body);
    req.end();
  });
}

module.exports = { sendWebhook };
