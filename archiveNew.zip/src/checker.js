'use strict';

const https = require('https');
const { isValidFormat, toGiftURL } = require('./generator');

const HEADERS = {
  'User-Agent':      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
  'Accept':          'application/json',
  'Accept-Language': 'en-US,en;q=0.9',
};

const BASE_DELAY = 500;

function httpGet(code, token) {
  return new Promise((resolve, reject) => {
    const headers = token ? { ...HEADERS, Authorization: token } : { ...HEADERS };
    const req = https.request({
      hostname: 'discord.com',
      path:     `/api/v9/entitlements/gift-codes/${code}?with_application=false&country_code=US`,
      method:   'GET',
      headers,
    }, (res) => {
      let raw = '';
      res.on('data', c => (raw += c));
      res.on('end', () => {
        let body = null;
        try { body = JSON.parse(raw); } catch (_) {}
        resolve({ status: res.statusCode, headers: res.headers, body });
      });
    });
    req.on('error', reject);
    req.setTimeout(10_000, () => { req.destroy(); reject(new Error('Timeout')); });
    req.end();
  });
}

async function checkCode(code, token = null) {
  code = String(code).trim()
    .replace(/https?:\/\/discord\.gift\//, '')
    .replace(/https?:\/\/discord\.com\/billing\/promotions\//, '');

  if (!isValidFormat(code)) {
    return { code, status: 'error', message: 'Invalid format — expected 16 or 24 alphanumeric characters.', data: null };
  }

  try {
    const { status, headers, body } = await httpGet(code, token);

    if (status === 200) {
      const plan  = body?.subscription_plan?.name  ?? 'Nitro';
      const price = ((body?.subscription_plan?.price ?? 0) / 100).toFixed(2);
      return { code, status: 'valid', message: `VALID — ${plan} ($${price}/mo) → ${toGiftURL(code)}`, data: body };
    }

    if (status === 404) return { code, status: 'invalid', message: 'Invalid — Code not found (404)', data: null };

    if (status === 429) {
      const retry = headers['retry-after'] ?? 5;
      return { code, status: 'ratelimit', message: `Rate limited — retry after ${retry}s`, data: { retryAfter: Number(retry) } };
    }

    return { code, status: 'error', message: `Unexpected HTTP ${status}`, data: body };
  } catch (err) {
    return { code, status: 'error', message: `Network error: ${err.message}`, data: null };
  }
}

async function checkBatch(codes, { concurrency = 2, delayMs = BASE_DELAY, token = null, onResult = null } = {}) {
  const results = [];
  const queue   = [...codes];
  const workers = Array.from({ length: Math.min(concurrency, codes.length) }, () =>
    _worker(queue, results, { delayMs, token, onResult })
  );
  await Promise.all(workers);
  return results;
}

async function _worker(queue, results, { delayMs, token, onResult }) {
  while (queue.length > 0) {
    const code = queue.shift();
    if (!code) break;
    const result = await checkCode(code, token);
    if (result.status === 'ratelimit') {
      await sleep((result.data?.retryAfter ?? 5) * 1000 + 500);
      queue.unshift(code);
      continue;
    }
    results.push(result);
    if (typeof onResult === 'function') onResult(result, results.length);
    await sleep(delayMs);
  }
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function summarise(results) {
  return {
    total:      results.length,
    valid:      results.filter(r => r.status === 'valid').length,
    invalid:    results.filter(r => r.status === 'invalid').length,
    errors:     results.filter(r => r.status === 'error').length,
    validCodes: results.filter(r => r.status === 'valid').map(r => r.code),
  };
}

module.exports = { checkCode, checkBatch, summarise, sleep };
